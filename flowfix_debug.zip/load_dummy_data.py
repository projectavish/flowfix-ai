import sqlite3
import pandas as pd
import os

DB_PATH = os.path.join("data", "workflow_data.db")
CSV_PATH = os.path.join("data","dummy_tasks.csv")  # Adjust path if you move the file

# Connect to SQLite DB
conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

# Clear existing entries to avoid UNIQUE constraint errors
cursor.execute("DELETE FROM tasks")
cursor.execute("DELETE FROM ml_predictions")
cursor.execute("DELETE FROM gpt_suggestions")
conn.commit()
print("✅ Existing data cleared from tasks, ml_predictions, and gpt_suggestions.")

# Load dummy task data
df = pd.read_csv(CSV_PATH)

# Fill NA to avoid errors
df = df.fillna("")

# Insert into 'tasks' table
task_values = df[[
    'task_id', 'task_name', 'assignee', 'status', 'priority',
    'project', 'actual_duration', 'is_delayed', 'bottleneck_type',
    'reassignment_count', 'comments', 'start_date', 'end_date'
]].values.tolist()

cursor.executemany("""
    INSERT INTO tasks (
        task_id, task_name, assignee, status, priority, 
        project, actual_duration, is_delayed, bottleneck_type, 
        reassignment_count, comments, start_date, end_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
""", task_values)

# Dummy predictions (optional)
for task in task_values:
    task_id = task[0]
    cursor.execute("""
        INSERT INTO ml_predictions (
            task_id, model_type, prediction_value, confidence_score, model_version
        ) VALUES (?, ?, ?, ?, ?)
    """, (task_id, 'duration_predictor', 5.0, 0.8, '1.0'))

# Dummy GPT suggestions (optional)
for task in task_values:
    task_id = task[0]
    suggestion_id = f"sugg_{task_id}"
    cursor.execute("""
        INSERT INTO gpt_suggestions (
            suggestion_id, task_id, suggestion_text, suggestion_type
        ) VALUES (?, ?, ?, ?)
    """, (suggestion_id, task_id, "This is a dummy suggestion.", "general"))

# Commit & close
conn.commit()
conn.close()
print("✅ Dummy data loaded successfully.")
